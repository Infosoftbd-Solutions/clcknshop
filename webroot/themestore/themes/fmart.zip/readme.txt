last updated 15-10-2022
bugs : 
    1. variant is not working add to card section
    